Song Library Project
Select SongLib.java to run

You may add songs, edit songs, and delete songs.
The functionality to play songs has not been implemented.

These songs will be saved after program termination.
