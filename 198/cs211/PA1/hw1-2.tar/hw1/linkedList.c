// Author: Kev Sharma kks107
#include <stdio.h>
#include <stdlib.h>

struct node {
    int value;
    struct node *next; 
};
typedef struct node Node;

void printList(Node *head)
{
    // Remember that the list will always be in sorted order.
    if(head==NULL){
        printf("\n");
        return;
    }
       

    Node *ptr = head;
    while(ptr!= NULL)
    {
        if(ptr->next==NULL){
            printf("%d", ptr->value);
            return;
        }

        if(ptr->value != ptr->next->value)
            printf("%d\t", ptr->value);
        
        ptr = ptr->next;
    }
    printf("\n");
} 

void print_numNodes(Node *head)
{
    Node *ptr = head;
    int count = 0;
    while(ptr != NULL)
    {
        ++count;
        ptr = (*ptr).next;
    }
    printf("%d\n", count);
}

Node* insertNode(Node *head, int val)
{
    Node *temp = (Node *)malloc(sizeof(Node));
    temp->value = val;
    temp->next = NULL;

    // if no elements
    if(head==NULL){
        return temp;
    }

    // if value of head is higher than val, then initalize it at front
    if(head->value >= val)
    {
        temp->next = head;
        head = temp;
        return head;
    }

    Node *ptr, *prev; 
    prev = head;
    ptr = prev->next;

    while(ptr!= NULL)
    {
        if(ptr->value >= val)
        {
            temp->next = prev->next;
            prev->next = temp;
            return head;
        }
        
        prev = prev->next;
        ptr = ptr->next; 
    }

    // insert at the end
    prev->next = temp;
    return head;
}

Node* deleteNode(Node *head, int target)
{
    if(head==NULL)
        return NULL;

    if(head->value==target) // if first node has a value of target, delete it
    {
        Node *temp = head;
        head = head->next;
        temp->next = NULL;
        free(temp);
        return head;
    }

    Node *ptr, *prev;
    prev = head;
    ptr = prev->next; // ptr points to second element;

    while(ptr!=NULL)
    {
        if(ptr->value > target) // linked List is in sorted order anyway
            return head;

        if(ptr->value == target)
        {
            prev->next = ptr->next;
            ptr->next = NULL;
            free(ptr);
            return head;
        }
        prev = prev->next;
        ptr = ptr->next;
    }
    return head;
}

int main(int argc, char* argv[])
{
    if(argc < 2){
        printf("error\n");
        return 0;
    }

    // initalize file
    char *filename = argv[1];
	FILE *fp = fopen(filename, "r");
    if(fp==NULL){
        printf("error\n");
        return 0;
    }
    
    Node *head = NULL;
    
    while(1)
    {
        char x;
        int y;

        int n = fscanf(fp, "%c\t%d\n", &x, &y);
        if(n!=2)
            break;
                
        if(x=='i')
            head = insertNode(head, y);
        if(x=='d')
            head = deleteNode(head, y);
    }
    fclose(fp);
    

    /* Output */
    print_numNodes(head);
    printList(head);
    printf("\n");

    // Must free all the nodes: head contains all the nodes that were not deleted
    Node *temp;
    while(head!=NULL)
    {
        temp = head;    // temp stores the first node to delete
        head = head->next; // head steps along the list
        free(temp);
    }
    temp = NULL;
    head = NULL;
}
