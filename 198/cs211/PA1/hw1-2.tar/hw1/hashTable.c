// Author: Kev Sharma kks107
#include <stdio.h>
#include <stdlib.h>

struct node{
    int value;
    struct node *next;
};
typedef struct node Node;

int successfulSearches = 0;
int numCollisions = 0;

/*Array of pointers to a linked List; 10000 buckets (0-9999) */
Node *(hashArray[10000]); // They must all start off as null;


int hashCode(int);
void search(int);
void insert(int);
void freeEverything();

int main(int argc, char* argv[])
{
    if (argc < 2){
        printf("error\n");
        return 0;
    }

    char *filename = argv[1];
	FILE *fp = fopen(filename, "r");
    if(fp == NULL){
        printf("error\n");
        return 0;
    }
    
    // All buckets point to empty linked lists at the start.
    for(int i=0; i<10000; i++)
        hashArray[i] = NULL;

    // insert all
    while(1)
    {
        int number;
        char x;

        int n = fscanf(fp, "%c\t%d\n", &x , &number);
        if(n!=2)
            break;
        
        // insert of search according to x
        if(x=='i')
            insert(number);
        else if(x=='s')
            search(number);
    }
    fclose(fp);

    printf("%d\n", numCollisions);
    printf("%d\n", successfulSearches);
    
    freeEverything();

}

int hashCode(int value)
{
    int n = value % 10000;
    
    if(n < 0){
        n += 10000;
    }
    
    return n;
}

void search(int value)
{
    /*
    *   Search whether a value exists;
    *   Check if value % 10000 has a LL that is not empty, and traverse to find if exists
    *   if LL is empty, then return;
    */
    int n = hashCode(value);
    
    Node *ptr = hashArray[n]; // ptr contains address of the LL stored by hashArray[n]
    while(ptr!=NULL)
    {
        if(ptr->value == value){
            ++successfulSearches;
            return;
        }

        ptr = ptr->next;
    }
}

void insert(int value)
{
    int checkDuplicate = successfulSearches;
    search(value);
    if(checkDuplicate != successfulSearches){
        // we found a duplicate
        ++numCollisions;
        --successfulSearches;
        return;
    }

    /*
    *   Determine where value will be stored in the hashTable by finding hashCode
    *   If the place at which we will insert has a linkedList that is empty then just insert
    *   Otherwise, increase numCollisions, and add to the front of linkedList
    */
    Node *temp = (Node *)malloc(sizeof(Node));
    temp->value = value;
    temp->next = NULL;

    int n = hashCode(value);
    
    if(hashArray[n] == NULL){ // No collision
        hashArray[n] = temp;
        return;
    }

    // collision but not a duplicate:
    temp->next = hashArray[n];
    hashArray[n] = temp;
    ++numCollisions;
}

void freeEverything()
{
    Node *ptr = NULL;
    for(int i=0; i<10000; i++){
        ptr = hashArray[i];
        
        Node *temp;
        while(ptr!=NULL){
            temp = ptr;
            ptr = ptr->next;
            free(temp);
        }
    }
}