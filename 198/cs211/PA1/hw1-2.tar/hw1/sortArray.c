// Author: Kev Sharma kks107
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int numEvens(int[], int);
void sortArray(int[], int, int);
void insertionSort(int [], int);

int main(int argc, char * argv[])
{
	if (argc < 2){
        printf("error\n");
        return 0;
    }

	char *filename = argv[1];
	FILE *fp = fopen(filename, "r");
	if(fp==0){
		printf("error\n");
		return 0; // fscanf failed assigning an address to fp, fp=0;
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////
	int arrayToSort[20]; 
	// Will have no more than 20 elements.	// Find how many integers will be in array
	int numElements;
	fscanf(fp, "%d\n", &numElements);
	
	//////////////////////////////////////////////////////////////////////////////////////////
	// Populate arrayToSort
	for(int i=0; i<numElements; i++){
		fscanf(fp, "%d\t", &arrayToSort[i]);
	}

	fclose(fp);
	//////////////////////////////////////////////////////////////////////////////////////////

	int numberOfEvens = numEvens(arrayToSort, numElements);
	int numberOfOdds = numElements - numberOfEvens;
	//printf("Number of Evens in our array: %d\n", numberOfEvens);	

	sortArray(arrayToSort, numElements, numberOfEvens);

	for(int i=0; i<numElements; i++){
		printf("%d\t", arrayToSort[i]);
	}
	printf("\n");
	
}

void sortArray(int ar[], int numberElements, int numberEvens)
{
	/* 
	*	Put all the evens in indices: 0-(numberEvens-1)
	*	Put all the odds in indices: numberEvens-(numberElements-1);
	*/
	int sorted[numberElements];
	int countEvens = 0; // used to populate the evens
	int countOdds = numberEvens;
	for(int i=0; i<numberElements; i++){
		if((ar[i]%2) == 0)
			sorted[countEvens++] = ar[i];
		else
			sorted[countOdds++] = ar[i];
	}
	
	// Sort the evens in ascending order
	// From 0 to numberEvens-1
	int sortEvens[numberEvens];
	for(int i=0; i<numberEvens; i++)
		sortEvens[i] = sorted[i];
	insertionSort(sortEvens, numberEvens);

	// Sort the odds in descending order
	// From numberEvens to numberElements-1`
	int sortOdds[numberElements-numberEvens];
	for(int i=numberEvens; i<numberElements; i++)
		sortOdds[i - numberEvens] = sorted[i]; 
	insertionSort(sortOdds, numberElements-numberEvens);
	// Reverse the ascending order to descending order
	int n = numberElements-numberEvens; // Size of the array sortOdds
	for(int i=0; i<n/2; i++){
		if(i>=(n-i-1))
			break;
		else{
			int temp = sortOdds[i];
			sortOdds[i] = sortOdds[n-i-1];
			sortOdds[n-i-1] = temp;
		}
	}
	
	// We have sortEvens and sortOdds both correct, now write them into ar[];
	for(int i=0; i<numberElements; i++)
	{
		if(i<numberEvens)
			ar[i] = sortEvens[i];
		else
			ar[i] = sortOdds[i-numberEvens];
		
	}
}
int numEvens(int ar[], int n)
{
	// ar holds n elements, return how many are even.
	int count = 0;
	for(int i=0; i<n; i++){
		if((ar[i] % 2) == 0)
			++count;
	}
		
	return count;
}
void insertionSort(int ar[], int n)
{
	// Simple insertionSort, not doing merge sort as only 20 max values
	int i, j, k; 
	for (i = 1; i < n; i++) // i has to be 1 for j to be 0
	{ 
		j = i - 1; 
		k = ar[i]; 
		
		while (j >= 0 && ar[j] > k) { 
			ar[j + 1] = ar[j]; 
			j = j - 1; 
		} 
		ar[j + 1] = k; 
	} 
}

