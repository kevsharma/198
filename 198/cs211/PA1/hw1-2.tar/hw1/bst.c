// Author: Kev Sharma kks107
#include <stdio.h>
#include <stdlib.h>

struct node {
    int value;
    struct node *left;
    struct node *right;
};
typedef struct node Node;

Node* insertNode(Node *head, int data)
{
    // if temp exists in the bst then ignore
    // preorder insert
    if(head == NULL){
        Node *temp = (Node*)malloc(sizeof(Node));
        temp->value = data;
        temp->left = NULL;
        temp->right = NULL;
        return temp;
    }
        //return temp;

    if(head->value < data)
        head->right = insertNode(head->right, data);

    else if(head->value > data)
        head->left = insertNode(head->left, data);

    return head;
}

void printNodes(Node *head) // preorder traversal
{
    if(head == NULL)
        return;

    // in order
    printNodes(head->left);
    printf("%d\t", head->value);
    printNodes(head->right);
}

void freeNodes(Node *head) // preorder free-ing
{
    if(head==NULL)
        return;
    
    freeNodes(head->left);
    freeNodes(head->right);
    free(head);
}

int main(int argc, char* argv[])
{
    Node *head = NULL;

    // input
    if (argc < 2){
        printf("error\n");
        return 0;
    }

    char *filename = argv[1];
	FILE *fp = fopen(filename, "r");
    if(fp == NULL){
        printf("error\n");
        return 0;
    }

    // insert all
    while(1)
    {
        int data;
        char x;

        int n = fscanf(fp, "%c\t%d\n", &x , &data);
        if(n!=2)
            break;
        
        if(x!='i')
            continue;
       
        head = insertNode(head, data);
    }
    fclose(fp);

    // Output
    printNodes(head);
    freeNodes(head);
    printf("\n");
}
