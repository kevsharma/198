// Author: Kev Sharma kks107
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(int argc, char* argv[])
{
	if(argc < 2){
		printf("\n");
		return 0;
	}
	
	// find out how long the sentence is, then malloc accordingly
	int sentenceSize = 0;
	for(int i=1; i<argc; i++){
			sentenceSize += strlen(argv[i]);
	}

	// iterate through all the words
			// iterate through all letters in the word
			// add any word that is a vowel (no matter case)

	char* vowels = (char *)malloc(sentenceSize * sizeof(char)+1);
	int count = 0; // will be used to print out final string
	
	for(int i=1; i<argc; i++)
	{
		char *ptr = argv[i];
		while(*ptr!='\0')
		{
				if(*ptr=='a'||*ptr=='e'||*ptr=='i'||*ptr=='o'||*ptr=='u' || *ptr=='A'||*ptr=='E'||*ptr=='I'||*ptr=='O'||*ptr=='U')
				{
					vowels[count] = *ptr;
					count++;
				}
				++ptr;
		}
	}
	*(vowels+count) = '\0'; //allows a quick print of vowels
	
	printf("%s\n", vowels);
	free(vowels);
	return 0;
}
