#ifndef ANALYSIS_THREADS_H
#define ANALYSIS_THREADS_H
void *analysis_thread_routine(void *arg);
#endif
