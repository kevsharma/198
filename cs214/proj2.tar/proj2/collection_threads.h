#ifndef COLLECTION_THREADS_H
#define COLLECTION_THREADS_H
void *dir_thread_routine(void *arg);
void *file_thread_routine(void *arg);
#endif
