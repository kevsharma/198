#ifndef DEBUGGER_H
#define DEBUGGER_H
#include "wf_repo.h"

int debug_wf_repo_print(wf_repo *);

#endif
