# Systems Programming Project 3: KEY-VALUE Storage Service
***

Michael Zhang&emsp;NetID: mz487

Kev Sharma&emsp;&emsp;&nbsp;NetID: kks107

***

## Description:
<p style="font-weight:500;">A program that starts and runs a server whose purpose involves taking in SET/GET/DEL requests from a client and responding appropriately to such requests.</p>

## Usage:
- To run the server, do the following:
    ```sh
    $ make
    ```
    ```sh
    $ ./server <port_number>
    ```
    The port number must be in the range (1024, 65535]. 1024 and below are reserved, and the maximum port number is 65535.
- Communicating with the server:
    ```sh
    $ cat <some_text_file> | netcat <host> <port>
    ```
    or
    ```sh
    $ netcat <host> <port>
    ```
    In either case, the format of the requests must follow the format specified:
    ```
    <request>\n<payload_length>\n<key>\n[<value>\n]
    ```
    example:
    ```
    GET \\ {SET, GET, DEL} are the case-sensitive set of acceptable requests
    4   \\ length is 4 because the payload is {'d','a','y','\n'}
    day
    SET
    11  \\ length is 11 because the payload is {'d','a','y','\n','S','u','n','d','a','y','\n'}
    day
    Sunday
    ```
    Note: When utilizing ```SET```, an empty value is ok, but an empty key is not as it is considered a malformed message by the server. Same for all the other requests. Empty keys are malformed.

***

## Testing:
- We initially tested with text files first, piping from ```stdin``` and writing to ```stdout```. This was done to test correctness of the hash tables and protocol, ensuring that we are parsing messages from clients correctly as well as correctly SETing, GETing and DELing.

    - Improperly formatted messages elicited ```ERR\nBAD\n``` or ```ERR\nLEN\n``` messages, and for messages whose keys have not yet been ```SET```, they received ```KNF\n```.
    - The tests to draw out the errors are as follows. They were employed to mimic receiving information from a client by reading in from a file; we wrote into this file (file.txt, passed in as 0 < file.txt):
	    1. malformed messages for SET, DEL, and GET.
	    2. non digit characters in the payload size portion.
	    3. instead of SET, we tried XET, SXT, SEX, and closed connection as soon as incorrect letter read without reading remainder of payload 
	    4. wrote more requests after a malformed request to check whether we moved onto those or correctly stopped reading.
	    5. incorrect length messages (not enough and too much) for SET, DEL, GET.
	    6. improper sequence of newlines to trigger length errors
	    7. GET and DEL requests to trigger KNF
	    8. DEL request, then GET request, to ensure our hash table deletes the key
	    9. SET day Sunday, SET day Tuesday, and then GET to ensure updated key
	    10. SET, then DEL, then DEL again to ensure OKS,OKD,KNF in that order.

- Having handled testing of the hash table and protocol, we could be confident that if any bugs appear later, the probability of an error originating from those mentioned pieces of our software would be lower. We then were able to move onto setting the up the code that would run the server.

  - For the server, the ability of the program to detect improper ports was tested. The only ports allowed were integer values between 1024 and 65535, and it was able to catch port numbers not in that range, including values that would be unable to be resolved to integers.
  - Following that, multiple clients were simulated by creating and running a bash script that would open multiple terminals, each of them piping large files filled with messages to netcat. Each of those simulated clients received the correct amount and format of responses back.# Systems-Programming-Project-3
