#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include "sync_htable.h"

unsigned long sh_hash_func(char *key) {
    /** dan bernstein - djb2 algorithm */
    unsigned long hash = 5381;
    int c = *key;
    while (c) {
        hash = ((hash << 5) + hash) + c;
        key++;
        c = *key;
    }
    return hash;
}

sync_htable *sh_create_table(int row_count, double y_val) {
    sync_htable *table = malloc(sizeof(sync_htable));
    if (!table) {
        perror("creating hash table");
        return 0;
    }
    table->no_entries = 0;
    table->no_rows = row_count;
    table->y = y_val;
    table->no_readers = 0;
    table->no_writers = 0;
    table->no_writing = 0;
    table->data = malloc(sizeof(key_val_pair *) * row_count);
    if (!table->data) {
        perror("creating hash table");
        free(table);
        return 0;
    }
    for (int i = 0; i < row_count; i += 1) {
        table->data[i] = 0;
    }
    if (pthread_mutex_init(&table->lock, NULL)) {
        perror("creating hash table");
        free(table->data);
        free(table);
        return 0;
    }
    if (pthread_cond_init(&table->cond, NULL)) {
        perror("creating hash table");
        pthread_mutex_destroy(&table->lock);
        free(table->data);
        free(table);
        return 0;
    }
    return table;
}

int sh_destroy(sync_htable *table) {
    for (int i = 0; i < table->no_rows; i += 1) {
        key_val_pair *ptr = table->data[i];
        key_val_pair *next = 0;
        while (ptr) {
            next = ptr->next;
            free(ptr->key);
            free(ptr->val);
            free(ptr);
            ptr = next;
        }
    }
    free(table->data);
    pthread_mutex_destroy(&table->lock);
    pthread_cond_destroy(&table->cond);
    free(table);
    return EXIT_SUCCESS;
}

char *sh_get(sync_htable *table, char *key, int sockfd, int *status) {
    char *res = 0;
    unsigned long hash = sh_hash_func(key);
    int idx = (int)((hash) % table->no_rows);
    pthread_mutex_lock(&table->lock);
    while (table->no_writers) {
        pthread_cond_wait(&table->cond, &table->lock);
    }
    table->no_readers += 1;
    pthread_mutex_unlock(&table->lock);
    key_val_pair *ptr = table->data[idx];
    while (ptr) {
        if (strcmp(ptr->key, key)==0) {
            break;
        }
        ptr = ptr->next;
    }
    free(key);
    if (ptr) {
        res = malloc(sizeof(char)*(strlen(ptr->val) + 1));
        if (res) {
            strcpy(res, ptr->val);
        } else {
            write(sockfd, "ERR\nSRV\n", 8);
            *status = ERR_STATUS;
        }
    } else {
        write(sockfd, "KNF\n", 4);
        *status = KNF_STATUS;
    }
    pthread_mutex_lock(&table->lock);
    table->no_readers -= 1;
    pthread_cond_broadcast(&table->cond);
    pthread_mutex_unlock(&table->lock);
    return res;
}

char *sh_del(sync_htable *table, char *key, int sockfd, int *status) {
    char *res = 0;
    unsigned long hash = sh_hash_func(key);
    int idx = (int)((hash) % table->no_rows);
    pthread_mutex_lock(&table->lock);
    table->no_writers += 1;
    while (table->no_writing || table->no_readers) {
        pthread_cond_wait(&table->cond, &table->lock);
    }
    table->no_writing += 1;
    pthread_mutex_unlock(&table->lock);
    key_val_pair *ptr = table->data[idx];
    key_val_pair *prev = 0;
    while (ptr) {
        if (strcmp(ptr->key, key)==0) {
            break;
        }
        ptr = ptr->next;
    }
    free(key);
    if (ptr) {
        res = malloc(sizeof(char)*(strlen(ptr->val) + 1));
        if (res) {
            strcpy(res, ptr->val);
            if (!prev) {
                table->data[idx] = ptr->next;
            } else {
                prev->next = ptr->next;
            }
            free(ptr->val);
            free(ptr->key);
            free(ptr);
            pthread_mutex_lock(&table->lock);
            table->no_entries -= 1;
            pthread_mutex_unlock(&table->lock);
        } else {
            write(sockfd, "ERR\nSRV\n", 8);
            *status = ERR_STATUS;
        }
    } else {
        write(sockfd, "KNF\n", 4);
        *status = KNF_STATUS;
    }
    pthread_mutex_lock(&table->lock);
    table->no_writing -= 1;
    table->no_writers -= 1;
    pthread_cond_broadcast(&table->cond);
    pthread_mutex_unlock(&table->lock);
    return res;
}

int sh_set(sync_htable *table, char *key, char *value, int sockfd) {
    int err_flag = 0;
    unsigned long hash = sh_hash_func(key);
    int idx = (int)((hash) % table->no_rows);
    pthread_mutex_lock(&table->lock);
    table->no_writers += 1;
    while (table->no_writing || table->no_readers) {
        pthread_cond_wait(&table->cond, &table->lock);
    }
    table->no_writing += 1;
    pthread_mutex_unlock(&table->lock);
    key_val_pair *ptr = table->data[idx];
    key_val_pair *prev = 0;
    while (ptr) {
        if (strcmp(ptr->key, key)==0) {
            break;
        }
        ptr = ptr->next;
    }
    if (ptr) {
        free(ptr->val);
        ptr->val = value;
        free(key);
    } else {
        key_val_pair *p = malloc(sizeof(key_val_pair));
        if (!p) {
            free(value);
            free(key);
            err_flag = 1;
        } else {
            p->val = value;
            p->key = key;
            p->hashcode = hash;
            p->next = 0;
            if (!prev) {
                table->data[idx] = p;
            } else {
                prev->next = p;
            }
            table->no_entries += 1;
        }
    }
    double y_prime = (double)table->no_entries/table->no_rows;
    if (y_prime > table->y) {
        sh_rehash(table);
    }
    pthread_mutex_lock(&table->lock);
    table->no_writers -= 1;
    table->no_writing -= 1;
    pthread_cond_broadcast(&table->cond);
    pthread_mutex_unlock(&table->lock);
    if (err_flag) {
        write(sockfd, "ERR\nSRV\n", 8);
        return ERR_STATUS;
    } else {
        write(sockfd, "OKS\n", 4);
        return OK_STATUS;
    }
}

int sh_rehash(sync_htable *table) {
    int new_no_rows = 2 * table->no_rows;
    key_val_pair **new_data = malloc(sizeof(key_val_pair *) * new_no_rows);
    if (!new_data) {
        return EXIT_FAILURE;
    }
    for (int i = 0; i < new_no_rows; i += 1) {
        new_data[i] = 0;
    }
    for (int i = 0; i < table->no_rows; i += 1) {
        key_val_pair *ptr = table->data[i];
        if (!ptr) {
            continue;
        } else {
            key_val_pair *next = 0;
            while (ptr) {
                next = ptr->next;
                int new_idx = (int)((ptr->hashcode) % new_no_rows);
                ptr->next = new_data[new_idx];
                new_data[new_idx] = ptr;
                ptr = next;
            }
        }
    }
    free(table->data);
    table->no_rows = new_no_rows;
    table->data = new_data;
    return EXIT_SUCCESS;
}
