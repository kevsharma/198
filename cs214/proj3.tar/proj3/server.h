#ifndef SERVER_H
#define SERVER_H

typedef struct {
    struct sockaddr_storage addr;
    socklen_t addr_len;
    int sockfd;
} connection;

int port_validator(char *port);
void server(char *port);
int create_server_port(char *port);
void *protocol_wrapper(void *arg);
#endif
