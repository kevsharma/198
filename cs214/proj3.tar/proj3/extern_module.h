#ifndef EXTERN_MODULE_H
#define EXTERN_MODULE_H

#include "sync_htable.h"

sync_htable *table;

#endif
