#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include "sync_htable.h"
#include "shwrapper.h"
#include "extern_module.h"

int no_digits(int num) {
    int count = 0;
    while (num > 0) {
        num /= 10;
        count += 1;
    }
    return count;
}

int shwrapper_get(char *key, int sockfd) {
    int status = 0;
    char *res = sh_get(table, key, sockfd, &status);
    if (status == KNF_STATUS) {
        return KNF_STATUS;
    } else if (status == ERR_STATUS) {
        return ERR_STATUS;
    } else {
        char *serv_res = 0;
        int payload_len = strlen(res) + 1;
        serv_res = malloc(sizeof(char) * (no_digits(payload_len) + payload_len + 6));
        if (!serv_res) {
            write(sockfd, "ERR\nSRV\n", 8);
            free(res);
            return ERR_STATUS;
        } else {
            sprintf(serv_res, "OKG\n%d\n%s\n", payload_len, res);
            free(res);
            write(sockfd, serv_res, strlen(serv_res));
            free(serv_res);
            return OK_STATUS;
        }
    }
}

int shwrapper_del(char *key, int sockfd) {
    int status = 0;
    char *res = sh_del(table, key, sockfd, &status);
    if (status == KNF_STATUS) {
        return KNF_STATUS;
    } else if (status == ERR_STATUS) {
        return ERR_STATUS;
    } else {
        char *serv_res = 0;
        int payload_len = strlen(res) + 1;
        serv_res = malloc(sizeof(char) * (no_digits(payload_len) + payload_len + 6));
        if (!serv_res) {
            write(sockfd, "ERR\nSRV\n", 8);
            free(res);
            return ERR_STATUS;
        } else {
            sprintf(serv_res, "OKD\n%d\n%s\n", payload_len, res);
            free(res);
            write(sockfd, serv_res, strlen(serv_res));
            free(serv_res);
            return OK_STATUS;
        }
    }
}

int shwrapper_set(char *key, char *value, int sockfd) {
    if (sh_set(table, key, value, sockfd) == ERR_STATUS) {
        return ERR_STATUS;
    }
    return OK_STATUS;
}
