#ifndef SYNC_HTABLE_H
#define SYNC_HTABLE_H

#include <pthread.h>

#define KNF_STATUS 1
#define ERR_STATUS -1
#define OK_STATUS 0

typedef struct key_val_pair {
    char *key;
    char *val;
    unsigned long hashcode;
    struct key_val_pair *next;
} key_val_pair;

/** writers prioritized over readers */
typedef struct sync_htable {
    pthread_cond_t cond;
    /** can be any number of readers >= 0 */
    int no_readers;
    /** can be any number of writers >= 0 */
    int no_writers;
    /** can only ever be 0 or 1 writing */
    int no_writing;
    pthread_mutex_t lock;
    int no_entries;
    int no_rows;
    double y;
    key_val_pair **data;
} sync_htable;

/*
 * input a string and outputs a hashcode
 */
unsigned long sh_hash_func(char *key);

/*
 * returns the following statuses:
 *      * ERR_STATUS - server error
 *      * OK_STATUS - successful request
 * ERR\nSRV\n and OKS are sent by this function
 */
int sh_set(sync_htable *table, char *key, char *value, int sockfd);

/*
 * returns the value associated with the key from the specified table
 * if not found or there was a server error, returns NULL
 *
 * ERR\nSRV\n is sent by this function when encountering internal error
 * KNF\n is sent by this function when the requested key is not present
 *
 * status is an int pointer to hold the following:
 *      * KNF_STATUS - indicates that such a key did not exist at the time of the request
 *      * ERR_STATUS - indicates a server error
 *      * OK_STATUS - indicates a successful operation. biconditional with a non NULL char * return
 */
char *sh_get(sync_htable *table, char *key, int sockfd, int *status);

/*
 * deletes the entry from the table
 * returns the value associated with the key from the specified table
 * if not found or there was a server error, returns NULL
 *
 * ERR\nSRV\n is sent by this function when encountering internal error
 * KNF\n is sent by this function when the requested key is not present
 *
 * status is an int pointer to hold the following:
 *      * KNF_STATUS - indicates that such a key did not exist at the time of the request
 *      * ERR_STATUS - indicates a server error
 *      * OK_STATUS - indicates a successful operation. biconditional with a non NULL char * return
 */
char *sh_del(sync_htable *table, char *key, int sockfd, int *status);

/** the success or failure of this method not relevant for the client */
int sh_rehash(sync_htable *table);

int sh_destroy(sync_htable *table);

sync_htable *sh_create_table(int row_count, double y_val);

#endif
