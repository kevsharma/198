#define _POSIX_C_SOURCE 200112L
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <ctype.h>
#include "server.h"
#include "protocol.h"
#include "sync_htable.h"
#include "extern_module.h"

#define BACKLOG 10

sync_htable *table;

int port_validator(char *port) {
    char *ptr;
    for (ptr = port; *ptr != '\0' && *ptr !='\n'; ptr++) {
        if (!isdigit(*ptr)) {
            fprintf(stderr, "port validator: %s is not a valid port\n", port);
            return EXIT_FAILURE;
        }
    }
    int port_val = atoi(port);
    if (port_val < 1024 || port_val > 65535) {
        fprintf(stderr, "%s is not a valid port number (must be in range [1024,65535])\n", port);
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}

int create_server_port(char *port) {
    int sockfd;
    struct addrinfo hints, *serv_info, *ptr;

    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    int status;

    int reuse = 1;

    if ((status = getaddrinfo(NULL, port, &hints, &serv_info)) != 0) {
        fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(status));
        return -1;
    }

    for (ptr = serv_info; ptr != NULL; ptr = ptr->ai_next) {
        if ((sockfd = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol)) == -1) {
            perror("socket()");
            continue;
        }
        if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(int)) == -1) {
            close(sockfd);
            perror("setsockopt()");
            freeaddrinfo(serv_info);
            return -1;
        }
        if (bind(sockfd, ptr->ai_addr, ptr->ai_addrlen) == -1) {
            close(sockfd);
            perror("bind()");
            continue;
        }
        if (listen(sockfd, BACKLOG) == -1) {
            close(sockfd);
            perror("listen()");
            continue;
        }
        break;
    }
    if (!ptr) {
        fprintf(stderr, "failed to bind or listen\n");
        freeaddrinfo(serv_info);
        return -1;
    }
    char hostname[1024];
    hostname[1023] = '\0';
    gethostname(hostname, 1023);
    fprintf(stdout, "HOST: %s - %s\n", hostname, port);
    freeaddrinfo(serv_info);
    return sockfd;
}

void *protocol_wrapper(void *arg) {
    connection *con = (connection *)arg;
    serviceRequest(&con->sockfd);
    free(con);
    return (void *) 0;
}

void server(char *port) {
    pthread_t tid;
    int err;
    connection *con;
    int server_socket = create_server_port(port);
    if (server_socket == -1) {
        exit(EXIT_FAILURE);
    }
    while (1) {
        con = malloc(sizeof(connection));
        if (!con) {
            perror("malloc connection");
            continue;
        }
        con->addr_len = sizeof(struct sockaddr_storage);
        con->sockfd = accept(server_socket, (struct sockaddr *)&con->addr, &con->addr_len);
        fprintf(stdout, "accepting connection\n");
        if (con->sockfd == -1) {
            free(con);
            perror("accept()");
            continue;
        }
        err = pthread_create(&tid, NULL, protocol_wrapper, con);
        if (err) {
            fprintf(stderr, "unable to create thread: %d\n", err);
            close(con->sockfd);
            free(con);
            continue;
        }
        pthread_detach(tid);
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Must input exactly two parameters, the executable name and the port number\n");
        exit(EXIT_FAILURE);
    }
    if (port_validator(argv[1])==EXIT_FAILURE) {
        exit(EXIT_FAILURE);
    }
    table = sh_create_table(20, 3.0);
    if (!table) {
        fprintf(stderr, "Could not create data structure for storing key-value pairs\n");
        exit(EXIT_FAILURE);
    }
    server(argv[1]);

    // won't reach this line
    sh_destroy(table);
    return EXIT_FAILURE;
}
