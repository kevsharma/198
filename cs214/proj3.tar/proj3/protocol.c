#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <sys/stat.h> 
#include <sys/types.h> 
#include <dirent.h>

#include "protocol.h"
#include "shwrapper.h"

#ifndef BUFSIZE
#define BUFSIZE 256
#endif

#define KNF_STATUS 1
#define ERR_STATUS -1
#define OK_STATUS 0

void* serviceRequest(void* socketfd){

    int sockfd = *((int*)(socketfd));
    // Initialization
    const char get[4] = "GET";
    const char set[4] = "SET";
    const char del[4] = "DEL";

    processing state = request;

    int payloadSize = 0; // number following the SET/GET/DEL, should be appended only in state = number

    strbuf_t keyB, valueB; // buffers for the key and value (since they may be cutoff), state = key or state = value
    // invoking keyB->used tells us length of string key, valueB->used tells us length of string value.

    strbuf_t messagetypeB; // buffer used to store the set/get/del, after calling append(&messagetypeB, char)
    // once we append, we check the size of buffer and accordingly compare it against GET/SET/DEL or a substring of those.

    if((sb_init(&messagetypeB, 24) + sb_init(&keyB, 24) + sb_init(&valueB, 24)) > 0){
        // one of the buffer unable to be initialized. // REPORT SERVER ERROR 
        write(sockfd, "ERR\nSRV\n", 8);
        sb_destroy(&messagetypeB); 
        sb_destroy(&keyB); 
        sb_destroy(&valueB);
        close(sockfd);
        return NULL;
    }

    // Algorithm for ensuring proper formatting and servicing requests.
    char buffer[BUFSIZE];
    int bytes = read(sockfd, buffer, BUFSIZE);
    int err_flag = 0;
    while (bytes > 0) {
        // Each time buffer[i] = '\n', we change states and ensure previous state formatted properly.
        // After we get \n after state is key/value, we can service our request provided keyB->used + valueB->used = payload - 2
        // Service request after switching state from key iff messagetypeB == get or del
        // Service request after switching state from value iff messagetypeB == set
        for(int i=0; i<bytes; i++){
            if (buffer[i] == '\0') {
                // null terminators are not allowed in our message according to the pdf
                write(sockfd, "ERR\nBAD\n", 8);
                err_flag = 1;
                break;
            }
            if(buffer[i] == '\n'){
                // we mark the end of a state when we find a newline
                if(state == request){
                    //printf("CAME TO REQUEST STATE CHANGE, |REQUEST| = %ld\n", messagetypeB.used);
                    if(messagetypeB.used != 3){
                        // malformed message, improper sequence of newline (not incorrect # of newlines)
                        write(sockfd, "ERR\nBAD\n", 8);
                        err_flag = 1;
                        break;
                    } 
                    // else, all good - proceed to next state
                    state = number;
                }
                else if(state == number){
                    if((strcmp(messagetypeB.data, set) == 0 && payloadSize <= 2) || payloadSize <= 1){
                        // not enough length.
                        // Suppose message is get/del, then we need a payloadSize of at least 2 (nonempty key + newline)
                        // If message is set, then we need two newlines and one nonempty key = at least 3.
                        write(sockfd, "ERR\nLEN\n", 8);
                        err_flag = 1;
                        break;
                    }
                    // else, all good - proceed to next state
                    state = key;
                }
                else if(state == key){
                    if(keyB.used == 0){
                        // They skipped key
                        write(sockfd, "ERR\nLEN\n", 8);
                        err_flag = 1;
                        break;
                    }
                    // request type could be either 3, has to match one otherwise error in state==request code.
                    if(strcmp(messagetypeB.data, get) == 0 || strcmp(messagetypeB.data, del) == 0){
                        if(keyB.used != (payloadSize - 1)){
                            // Length problem
                            write(sockfd, "ERR\nLEN\n", 8);
                            err_flag = 1;
                            break;
                        }
                        // Prepare the char* that will be passed in.
                        char* keyBData = malloc(sizeof(char) * (keyB.used + 2));
                        if(!keyBData){
                            write(sockfd, "ERR\nSRV\n", 8);
                            err_flag = 1;
                            break;
                        }
                        strcpy(keyBData, keyB.data);

                        // Service the request and change state.
                        if(strcmp(messagetypeB.data, get) == 0){
                            // GET request
                            if(shwrapper_get(keyBData, sockfd) == ERR_STATUS){
                                err_flag = 1;
                                break;
                            }                                
                        }
                        else if(strcmp(messagetypeB.data, del) == 0){
                            // DEL request
                            if(shwrapper_del(keyBData, sockfd) == ERR_STATUS){
                                err_flag = 1;
                                break;
                            }  
                        }
                        // Request serviced, reset message
                        //printf("request serviced for GET or DEL\n");
                        sb_reset(&keyB);
                        sb_reset(&messagetypeB);
                        payloadSize = 0;
                        state = request;
                    }
                    else if(strcmp(messagetypeB.data, set) == 0){
                        state = value;
                    }
                }
                else if(state == value){
                    // we know the request type is SET
                    if((keyB.used + valueB.used) != (payloadSize - 2)){
                        // Length problem
                        write(sockfd, "ERR\nLEN\n", 8);
                        err_flag = 1;
                        break;
                    }
                    // Service the set request
                    // Prepare the char* key and value that will be passed in to shwrappepr_set.
                    char* keyBData = malloc(sizeof(char) * (keyB.used + 2));
                    if(!keyBData){
                        write(sockfd, "ERR\nSRV\n", 8);
                        err_flag = 1;
                        break;
                    }
                    strcpy(keyBData, keyB.data);

                    char* valueBData = malloc(sizeof(char) * (valueB.used + 2));
                    if(!valueBData){
                        write(sockfd, "ERR\nSRV\n", 8);
                        err_flag = 1;
                        break;
                    }
                    strcpy(valueBData, valueB.data);
                    if(shwrapper_set(keyBData, valueBData, sockfd) == ERR_STATUS){
                        err_flag = 1;
                        break;
                    }
                    // I do not free keyBData and valueBData, that is shwrapper_set's job.

                    // Request serviced, reset message

                    //printf("request serviced for SET\n");
                    sb_reset(&keyB);
                    sb_reset(&valueB);
                    sb_reset(&messagetypeB);
                    payloadSize = 0;
                    state = request;
                }

    //printf("state change happened to state %d\n", state);
    //printBUFFs(i, &keyB, &messagetypeB, &valueB, payloadSize);
                continue;
            }

            // otherwise we append to some buffer based on which state we are in.
            if(state == request){
                int n = messagetypeB.used;
                if(n >= 3){
                    // malformed message, against protocol`
                    write(sockfd, "ERR\nBAD\n", 8);
                    err_flag = 1;
                    break;
                }
                // Proper message so far.
                sb_append(&messagetypeB, buffer[i]);
                ++n;
                
                // However, if the char appended to requestType no longer is a subset of GET/DEL/SET, then error..
                if(strncmp(messagetypeB.data,get,n) != 0 && strncmp(messagetypeB.data,del,n) != 0 && strncmp(messagetypeB.data,set,n) != 0){
                    // none of the message types matched.
                    write(sockfd, "ERR\nBAD\n", 8);
                    err_flag = 1;
                    break;
                }
                
            }
            else if(state == number){
                if(!isdigit(buffer[i])){
                    // malformed message
                    write(sockfd, "ERR\nBAD\n", 8);
                    err_flag = 1;
                    break;
                }
                payloadSize *= 10;
                payloadSize += ((int)buffer[i] - 48);
            }
            else if(state == key){
                if( ( strcmp(messagetypeB.data, set) == 0 && keyB.used>=(payloadSize-2) ) || keyB.used>=(payloadSize-1) ){
                    // not enough length.
                    // Suppose message is get/del, then we need a payloadSize of at least 2 (nonempty key + newline)
                    // If message is set, then we need two newlines and one nonempty key = at least 3.
                    write(sockfd, "ERR\nLEN\n", 8);
                    err_flag = 1;
                    break;
                }

                if(sb_append(&keyB, buffer[i]) == 1){
                    // Server error from sb_append.
                    write(sockfd, "ERR\nSRV\n", 8);
                    err_flag = 1;
                    break;
                }
            }
            else if(state == value){
                if((keyB.used + valueB.used) >= (payloadSize-2)){ // can't append since no room for newline
                    // exceeds Length message, against protocol
                    write(sockfd, "ERR\nLEN\n", 8);
                    err_flag = 1;
                    break;
                }
                if(sb_append(&valueB, buffer[i]) == 1){
                    // Server error from sb_append.
                    write(sockfd, "ERR\nSRV\n", 8);
                    err_flag = 1;
                    break;
                }
            }

    //printBUFFs(i, &keyB, &messagetypeB, &valueB, payloadSize);
        }
        if (err_flag == 1) {
            break;
        }
        bytes = read(sockfd, buffer, BUFSIZE);
    }

    // Client has chosen to close connection. Do not proceed to service last request.
    sb_destroy(&messagetypeB); 
    sb_destroy(&keyB); 
    sb_destroy(&valueB);
    close(sockfd);

    fprintf(stdout, "closing connection\n");

    return NULL;
}

void printBUFFs(int i, strbuf_t *k, strbuf_t *m, strbuf_t *v, int p){
    printf("i=%d, payload size is %d: \n", i, p);
    printf("message type: ");
    dump(m);
    printf("key         : ");
    dump(k);
    printf("value       : ");
    dump(v);
    printf("\n\n");
}

int sb_reset(strbuf_t *sb){
    sb->used = 0;
    sb->data[sb->used] = '\0';
    return 0;
}

int sb_init(strbuf_t *sb, size_t length)
{
    if(length < 1){
        return 1;
    }
    
    sb->data = malloc(sizeof(char) * length);
    if (!sb->data) return 1;

    sb->length = length;
    sb->used   = 0;
    sb->data[sb->used] = '\0';

    return 0;
}

int sb_remove(strbuf_t *sb, char* item){
    // if nothing to remove, can't return anything
    if(sb->used == 0)
        return 1;
    
    --sb->used;
    if (item)
        *item = sb->data[sb->used];

    sb->data[sb->used] = '\0';
    return 0;
}

void sb_destroy(strbuf_t *sb)
{
    free(sb->data);
}

int sb_append(strbuf_t *sb, char item){
    if((sb->used+1) == sb->length){
        size_t size = sb->length * 2;
        char *p = realloc(sb->data, sizeof(char)* size);
        if(!p) return 1;
        // successful
        sb->data = p;
        sb->length = size;
    }

    sb->data[sb->used] = item;
    ++sb->used;
    sb->data[sb->used] = '\0';
    return 0;
}

int sb_concat(strbuf_t *sb, char *str){
    if((sb->used + strlen(str)) >= sb->length){
        size_t size = ((sb->used + strlen(str) + 1) > 2 * sb->length) ? (sb->used + strlen(str) + 1) : 2*sb->length;
        char *p = realloc(sb->data, sizeof(char)* size);
        if(!p) return 1;
        // successful
        sb->data = p;
        sb->length = size;
        //if (DEBUG) idk what this is for
        //    printf("Increased size to %lu\n", size);
    }
    
    int count = 0;
    while(count < strlen(str)){
        sb->data[sb->used+count] = *(str+count);
        ++count;
    }
    sb->data[sb->used+count] = '\0';
    sb->used += count;
    return 0;
}

int sb_insert(strbuf_t *sb, int index, char item){
    if(index <= sb->used){
        ++sb->used;
        if(sb->used == sb->length){
            size_t size = 2*sb->length;
            char *p = realloc(sb->data, sizeof(char)* size);
            if(!p) return 1;
            // successful
            sb->data = p;
            sb->length = size;
        } // we have enough space to shift everything over
    
        sb->data[sb->used] = '\0';
        // start from index, shift everything over until you get to null term
        char temp;
        for(int i=index; i<sb->used; i++){
            temp = sb->data[i];
            sb->data[i] = item;
            item = temp;
        }
        
        return 0;
    }
    else{ // we know that index > used
        if((index+1) >= (2*sb->length)){
            size_t size = index+2;
            char *p = realloc(sb->data, sizeof(char)* size);
            if(!p) return 1;
            // successful
            sb->data = p;
            sb->length = size;
            sb->data[index] = item;
            sb->data[index+1] = '\0';
            sb->used = index+1;
            return 0;
        } // we know that index+1 is less than 2*sb->length
        // so it will fit between used and length
        // need to check if enough length to cover, if not double
        else{
            if(index+1 >= sb->length){
                size_t size = 2*sb->length;
                char *p = realloc(sb->data, sizeof(char)* size);
                if(!p) return 1;
                // successful
                sb->data = p;
                sb->length = size;
                sb->data[index] = item;
                sb->data[index+1] = '\0';
                sb->used = index+1;
                return 0;
            }
            else{
                // index+1 is > used but less than length
                sb->data[index] = item;
                sb->data[index+1] = '\0';
                sb->used = index+1;
                return 0;
            }
        }
    }
}

void dump(strbuf_t *sb){
    int i=0;
    printf("[%ld/%ld]\t", sb->used, sb->length);
    for(; i<sb->used; i++){
        printf("%c ", sb->data[i]);
    }
    printf("/0 "); ++i;
    for(; i<sb->length; i++){
        printf("_ ");
    }
    putchar('\n');
}
