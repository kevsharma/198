#ifndef PROTOCOL_H
#define PROTOCOL_H

// Protocol.c prototypes
typedef enum {
    request, number, key, value
} processing;

void* serviceRequest(void*);


// String buffer prototypes

typedef struct {
    size_t length;
    size_t used;
    char *data;
} strbuf_t;

int sb_init(strbuf_t *, size_t);
void sb_destroy(strbuf_t *); // frees memory allocated in this struct
int sb_append(strbuf_t *, char); // put char at used, ++used (double if nec)
int sb_remove(strbuf_t *, char*); // removes last char -> used-1
int sb_insert(strbuf_t *, int, char);
int sb_reset(strbuf_t *); // used for project 1

/* additional one */
/*
    sb_concat adds the string str to the end of the string held in sb. 
    Assume that str is a null-terminated C string. 
    Return 0 if successful, and 1 otherwise.
*/
int sb_concat(strbuf_t *, char*); // append cannot append strings

void dump(strbuf_t *sb);

void printBUFFs(int i, strbuf_t *k, strbuf_t *m, strbuf_t *v, int p);

#endif
