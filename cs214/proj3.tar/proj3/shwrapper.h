#ifndef SHWRAPPER_H
#define SHWRAPPER_H

#define ERR_STATUS -1
#define KNF_STATUS 1
#define OK_STATUS 0

int no_digits(int num);

/*
 * returns ERR_STATUS if a server error, KNF_STATUS if the key does not exist in the table, and OK_STATUS if the request was a success
 */
int shwrapper_get(char *key, int sockfd);

/*
 * returns ERR_STATUS if a server error, KNF_STATUS if the key does not exist in the table, and OK_STATUS if the request was a success
 */
int shwrapper_del(char *key, int sockfd);

/*
 * returns ERR_STATUS if server error, OK_STATUS if the request was a success
 */
int shwrapper_set(char *key, char *value, int sockfd);

#endif
